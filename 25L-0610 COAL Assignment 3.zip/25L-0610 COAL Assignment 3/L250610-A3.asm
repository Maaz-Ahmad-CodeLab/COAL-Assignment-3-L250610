[org 0x0100]
jmp start

title: db '25L-0610', 0
paragraph: db 'My name is Maaz Ahmad, a University student', 10
           db 'I go to FAST University', 10
           db 'I was about to go to LUMS University though', 10
           db 'Test text to check wrap and boundaries, Test text to check wrap and boundaries, Test text to check wrap and boundaries', 0
search: db 'University', 0
msg1: db 'Total Matches Found: [', 0
msg2: db '] | Viewport Status: ACTIVE', 0

clrscr:
    push bp
    mov bp, sp
    push es
    push ax
    push cx
    push di

    mov ax, 0xb800
    mov es, ax
    mov di, 0
    mov ax, [bp+4]
    mov cx, 2000

    cld
    rep stosw

    pop di
    pop cx
    pop ax
    pop es
    pop bp
    ret 2

getOffset:
    push bp
    mov bp, sp
    push dx

    mov ax, [bp+6]
    mov dx, 80
    mul dx
    add ax, [bp+4]
    shl ax, 1

    pop dx
    pop bp
    ret 4

viewport:
    push bp
    mov bp, sp
    sub sp, 4

    push es
    push ax
    push cx
    push di

    cld

    mov ax, 0xb800
    mov es, ax

    mov ax, [bp+4]
    sub ax, [bp+8]
    dec ax
    mov [bp-2], ax

    push word [bp+10]
    push word [bp+8]
    call getOffset

    mov di, ax
    mov ax, 0x07C9
    stosw

    mov ax, 0x07CD
    mov cx, [bp-2]
    rep stosw

    mov ax, 0x07BB
    stosw

    mov ax, [bp+10]
    inc ax
    mov [bp-4], ax

viewportSidesLoop:
    mov ax, [bp-4]
    cmp ax, [bp+6]
    jae viewportBottom

    push ax
    push word [bp+8]
    call getOffset

    mov di, ax
    mov ax, 0x07BA
    stosw

    mov cx, [bp-2]
    shl cx, 1
    add di, cx
    stosw

    inc word [bp-4]
    jmp viewportSidesLoop

viewportBottom:
    push word [bp+6]
    push word [bp+8]
    call getOffset

    mov di, ax
    mov ax, 0x07C8
    stosw

    mov ax, 0x07CD
    mov cx, [bp-2]
    rep stosw

    mov ax, 0x07BC
    stosw

    pop di
    pop cx
    pop ax
    pop es

    add sp, 4
    pop bp
    ret 8

printStr:
    push bp
    mov bp, sp

    push si
    push di
    push es

    cld

    mov ax, 0xb800
    mov es, ax
    mov di, [bp+8]
    mov si, [bp+4]
    mov ah, [bp+6]

printStringLoop:
    lodsb
    cmp al, 0
    je printStringEnd

    stosw
    jmp printStringLoop

printStringEnd:
    mov ax, di

    pop es
    pop di
    pop si
    pop bp
    ret 6

printPara:
    push bp
    mov bp, sp
    sub sp, 4

    push si
    push ax
    push es
    push di

    cld

    mov ax, 0xb800
    mov es, ax
    mov si, [bp+6]
    mov word [bp-2], 4

paragraphNextLine:
    push word [bp-2]
    mov ax, 10
    push ax
    call getOffset

    mov di, ax
    mov word [bp-4], 0

paragraphCharacterLoop:
    mov ax, [bp+4]
    lodsb

    cmp al, 0
    je paragraphEnd

    cmp al, 10
    je paragraphLineBreak

    stosw
    inc word [bp-4]

    cmp word [bp-4], 61
    je paragraphLineBreak

    jmp paragraphCharacterLoop

paragraphLineBreak:
    inc word [bp-2]
    cmp word [bp-2], 21
    jge paragraphEnd

    jmp paragraphNextLine

paragraphEnd:
    pop di
    pop es
    pop ax
    pop si

    add sp, 4
    pop bp
    ret 4

scroll:
    push bp
    mov bp, sp
    sub sp, 6

    push ax
    push bx
    push cx
    push si
    push di
    push ds
    push es

    mov ax, 0xb800
    mov ds, ax
    mov es, ax

    cld

    mov ax, [bp+6]
    sub ax, [bp+10]
    inc ax
    mov [bp-4], ax

    mov bx, 160
    sub bx, ax
    sub bx, ax
    mov [bp-6], bx

    mov ax, [bp+8]
    sub ax, [bp+12]
    inc ax
    sub ax, [bp+4]
    mov [bp-2], ax

    push word [bp+12]
    push word [bp+10]
    call getOffset

    mov di, ax

    mov ax, [bp+12]
    add ax, [bp+4]
    push ax
    push word [bp+10]
    call getOffset

    mov si, ax

scrollMoveLoop:
    cmp word [bp-2], 0
    jle scrollBlankStart

    mov cx, [bp-4]
    rep movsw

    add si, [bp-6]
    add di, [bp-6]

    dec word [bp-2]
    jmp scrollMoveLoop

scrollBlankStart:
    mov ax, [bp+4]
    mov [bp-2], ax
    mov ax, 0x0720

scrollBlankLoop:
    cmp word [bp-2], 0
    jle scrollEnd

    mov cx, [bp-4]
    rep stosw

    add di, [bp-6]
    dec word [bp-2]

    jmp scrollBlankLoop

scrollEnd:
    pop es
    pop ds
    pop di
    pop si
    pop cx
    pop bx
    pop ax

    add sp, 6
    pop bp
    ret 10

highlight:
    push bp
    mov bp, sp
    sub sp, 6

    push bx
    push si
    push di
    push es

    cld

    mov ax, 0xb800
    mov es, ax

    mov word [bp-2], 0
    mov word [bp-4], 4

highlightRowLoop:
    push word [bp-4]
    mov ax, 9
    push ax
    call getOffset

    mov di, ax
    mov word [bp-6], 63

highlightCellLoop:
    mov bx, di
    mov si, [bp+6]

highlightCompareLoop:
    lodsb

    cmp al, 0
    je highlightMatchFound

    scasb
    jne highlightNextCell

    inc di
    jmp highlightCompareLoop

highlightMatchFound:
    inc word [bp-2]
    mov ax, [bp+4]

highlightColorLoop:
    mov [es:di-1], al
    sub di, 2

    cmp di, bx
    ja highlightColorLoop

highlightNextCell:
    mov di, bx
    add di, 2

    dec word [bp-6]
    jnz highlightCellLoop

    inc word [bp-4]
    cmp word [bp-4], 21
    jb highlightRowLoop

    mov ax, [bp-2]

    pop es
    pop di
    pop si
    pop bx

    add sp, 6
    pop bp
    ret 4

printNum:
    push bp
    mov bp, sp
    sub sp, 2

    push bx
    push dx
    push di
    push es

    mov ax, 0xb800
    mov es, ax

    mov ax, [bp+6]
    mov di, [bp+4]
    mov bx, 10
    mov word [bp-2], 0

numberDivideLoop:
    xor dx, dx
    div bx

    push dx
    inc word [bp-2]

    cmp ax, 0
    jne numberDivideLoop

numberPrintLoop:
    pop dx
    add dl, '0'
    mov dh, 0x07

    mov [es:di], dx
    add di, 2

    dec word [bp-2]
    jnz numberPrintLoop

    mov ax, di

    pop es
    pop di
    pop dx
    pop bx

    add sp, 2
    pop bp
    ret 4

status:
    push bp
    mov bp, sp
    push ax

    mov ax, 3680
    push ax

    mov ax, 0x07
    push ax

    mov ax, msg1
    push ax

    call printStr

    push word [bp+4]
    push ax

    call printNum

    push ax

    mov ax, 0x07
    push ax

    mov ax, msg2
    push ax

    call printStr

    pop ax
    pop bp
    ret 2

start:
    mov ax, 0x0720
    push ax
    call clrscr

    mov ax, 3
    push ax

    mov ax, 8
    push ax

    mov ax, 21
    push ax

    mov ax, 72
    push ax

    call viewport

    mov ax, 552
    push ax

    mov ax, 0x1E
    push ax

    mov ax, title
    push ax

    call printStr

    mov ax, paragraph
    push ax

    mov ax, 0x0700
    push ax

    call printPara

    mov ah, 0
    int 0x16

    mov ax, 4
    push ax

    mov ax, 9
    push ax

    mov ax, 20
    push ax

    mov ax, 71
    push ax

    mov ax, 1
    push ax

    call scroll

    mov ax, search
    push ax

    mov ax, 0xCE
    push ax

    call highlight

    push ax
    call status

    mov ah, 0
    int 0x16

    mov ax, 0x4C00
    int 0x21